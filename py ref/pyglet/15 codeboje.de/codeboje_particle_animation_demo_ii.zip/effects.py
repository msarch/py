import glob, re
import pyglet
from pyglet.image import Animation, AnimationFrame
window = pyglet.window.Window()

white = (1,1,1,0)
black = (0,0,0,0)

rgb_white = (255,255,255,255)
rgb_black = (0,0,0,255)
pyglet.gl.glClearColor(*white)

effects = []
use_effect = 0

def create_effect_animation(image_name):
    img = pyglet.image.load(image_name)
    columns = img.width /192
    rows = img.height /192
    effect_seq = pyglet.image.ImageGrid(img, rows, columns).get_texture_sequence()
    effect_frames = []
    for row in range(rows, 0, -1):
        end = row * columns
        start = end - (columns -1) -1
        for effect_frame in effect_seq[start:end:1]:
            effect_frames.append(AnimationFrame(effect_frame, 0.1))
    
    effect_frames[(rows * columns) -1].duration = None
    return Animation(effect_frames)

effect_anims = []
for effect_file in glob.glob('effects/_LPE__*.png'):
    m = re.match(r".*_LPE__(.*)_by.*", effect_file)
    key = m.group(1)
    effect_anims.append({'key':key, 'value':create_effect_animation(effect_file) })

label = pyglet.text.Label('Effect: '+ effect_anims[use_effect]['key'],
                          font_name='Times New Roman',
                          font_size=18,
                          x=30, y=30,
                          anchor_x='left', anchor_y='center', color = rgb_black)

class EffectSprite(pyglet.sprite.Sprite):
    def on_animation_end(self):
        self.delete()
        effects.remove(self)

@window.event
def on_mouse_press(x, y, button, modifiers):
    if(pyglet.window.mouse.LEFT == button):
        effect = EffectSprite(effect_anims[use_effect]['value'])
        effect.position = (x-effect.width/2, y - effect.height/2)
        effects.append(effect)

@window.event
def on_key_press(symbol, modifiers):
    global use_effect
    if symbol == pyglet.window.key.B:
        pyglet.gl.glClearColor(*black)
        label.color = rgb_white
    if symbol == pyglet.window.key.W:
        pyglet.gl.glClearColor(*white)
        label.color = rgb_black
    if symbol == pyglet.window.key.UP:
        use_effect +=1
        if use_effect > len(effect_anims) -1:
            use_effect = len(effect_anims) -1
        label.text = 'Effect: ' + effect_anims[use_effect]['key']
    if symbol == pyglet.window.key.DOWN:
        use_effect -= 1
        if use_effect < 0:
            use_effect = 0
        label.text = 'Effect: ' + effect_anims[use_effect]['key']
        
@window.event
def on_draw():
    window.clear()
    label.draw()
    for effect in effects:
        effect.draw()

pyglet.app.run()