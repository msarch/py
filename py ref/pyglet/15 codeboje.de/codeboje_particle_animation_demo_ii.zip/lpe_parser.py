from PIL import Image, ImageOps
import glob, os, sys


pattern = sys.argv[1] + "\*.png"

for infile in glob.glob(pattern):
    path, filename = os.path.split(infile)
    im = Image.open(infile)
    parsed_folder = path + "/parsed" 
    if not os.path.exists(parsed_folder):
        os.mkdir(parsed_folder)
    
    im_gray = ImageOps.grayscale(im.copy())
    im_new = im.copy()   
    im_new.putalpha(im_gray)
    im_new.save(parsed_folder + "/" + filename, "png")
