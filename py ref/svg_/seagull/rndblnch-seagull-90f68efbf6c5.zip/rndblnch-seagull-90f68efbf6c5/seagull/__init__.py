# -*- coding: utf-8 -*-

"""seagull module"""

